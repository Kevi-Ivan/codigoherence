/**
 * Subclase: sensor de temperatura ambiental (°C).
 * Hereda de SensorAgricola y especializa el reporte.
 */
public class SensorTemperatura extends SensorAgricola {

    private double temperaturaMaxima; // °C maximos tolerados por el cultivo

    public SensorTemperatura(String codigo, String ubicacion, double temperaturaMaxima) {
        super(codigo, ubicacion); // constructor de la superclase
        this.temperaturaMaxima = temperaturaMaxima;
    }

    public boolean hayEstresTermico() {
        return ultimaLectura > temperaturaMaxima;
    }

    public double convertirAFahrenheit() {
        return ultimaLectura * 9 / 5 + 32;
    }

    public void setTemperaturaMaxima(double temperaturaMaxima) {
        this.temperaturaMaxima = temperaturaMaxima;
    }

    public double getTemperaturaMaxima() { return temperaturaMaxima; }

    @Override
    public String generarReporte() {
        return super.generarReporte() + " °C | Max. tolerada: " + temperaturaMaxima
             + " °C | Estres termico: " + (hayEstresTermico() ? "SI" : "NO");
    }
}
