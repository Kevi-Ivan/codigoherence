public class Main {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE SENSORES IoT AGRICOLAS - ESPAM MFL ===\n");

        SensorHumedad humedad = new SensorHumedad("HUM-001", "Lote A - Maíz", 35.0);
        SensorTemperatura temp = new SensorTemperatura("TMP-001", "Lote B - Cacao", 32.0);

        System.out.println("--- Estado inicial ---");
        System.out.println(humedad.generarReporte());
        System.out.println(temp.generarReporte());

        System.out.println("\n--- Registro de lecturas ---");
        humedad.registrarLectura(28.5);
        temp.registrarLectura(34.2);
        System.out.println(humedad.generarReporte());
        System.out.println(temp.generarReporte());

        System.out.println("\n--- Modificacion de parámetros ---");
        humedad.setUmbralRiego(25.0);
        temp.setTemperaturaMaxima(36.0);
        System.out.println(humedad.generarReporte());
        System.out.println(temp.generarReporte());
        System.out.printf("Temperatura en °F: %.1f%n", temp.convertirAFahrenheit());

        System.out.println("\n--- Desactivacion de sensor ---");
        humedad.desactivar();
        humedad.registrarLectura(60.0);
        System.out.println(humedad.generarReporte());

        System.out.println("\n--- Validacion del constructor ---");
        try {
            new SensorHumedad("", "Lote C", 40.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Error controlado: " + e.getMessage());
        }
    }
}
