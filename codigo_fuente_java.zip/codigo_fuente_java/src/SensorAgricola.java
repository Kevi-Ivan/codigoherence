/**
 * Superclase base: representa un sensor IoT desplegado en un cultivo.
 * Los atributos protegidos son accesibles por las subclases.
 */
public class SensorAgricola {

    protected String codigo;
    protected String ubicacion;
    protected double ultimaLectura;
    protected boolean activo;

    public SensorAgricola(String codigo, String ubicacion) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El codigo del sensor es obligatorio.");
        }
        if (ubicacion == null || ubicacion.isBlank()) {
            throw new IllegalArgumentException("La ubicacion del sensor es obligatoria.");
        }
        this.codigo = codigo;
        this.ubicacion = ubicacion;
        this.ultimaLectura = 0.0;
        this.activo = true;
    }

    public void registrarLectura(double valor) {
        if (!activo) {
            System.out.println("[AVISO] Sensor " + codigo + " desactivado: lectura ignorada.");
            return;
        }
        this.ultimaLectura = valor;
    }

    public void desactivar() { this.activo = false; }
    public void activar()    { this.activo = true; }

    public String getCodigo()        { return codigo; }
    public String getUbicacion()     { return ubicacion; }
    public double getUltimaLectura() { return ultimaLectura; }
    public boolean isActivo()        { return activo; }

    public String generarReporte() {
        return "Sensor " + codigo + " | Ubicación: " + ubicacion
             + " | Estado: " + (activo ? "ACTIVO" : "INACTIVO")
             + " | Última lectura: " + ultimaLectura;
    }
}
