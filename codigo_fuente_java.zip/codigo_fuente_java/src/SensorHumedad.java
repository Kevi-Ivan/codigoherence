/**
 * Subclase: sensor de humedad del suelo (%).
 * Hereda de SensorAgricola y especializa el reporte.
 */
public class SensorHumedad extends SensorAgricola {

    private double umbralRiego; // % minimo antes de requerir riego

    public SensorHumedad(String codigo, String ubicacion, double umbralRiego) {
        super(codigo, ubicacion); // constructor de la superclase
        if (umbralRiego < 0 || umbralRiego > 100) {
            throw new IllegalArgumentException("El umbral debe estar entre 0 y 100 %.");
        }
        this.umbralRiego = umbralRiego;
    }

    public boolean requiereRiego() {
        return ultimaLectura < umbralRiego; // acceso directo a miembro protected
    }

    public void setUmbralRiego(double umbralRiego) {
        if (umbralRiego >= 0 && umbralRiego <= 100) {
            this.umbralRiego = umbralRiego;
        }
    }

    public double getUmbralRiego() { return umbralRiego; }

    @Override
    public String generarReporte() {
        return super.generarReporte() + " %HR | Umbral de riego: " + umbralRiego
             + " % | Requiere riego: " + (requiereRiego() ? "SÍ" : "NO");
    }
}
